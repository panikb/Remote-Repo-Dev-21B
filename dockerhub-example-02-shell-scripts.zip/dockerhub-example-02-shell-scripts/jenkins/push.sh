#!/bin/bash
docker push darinpope/dp-alpine:latest