#!/bin/bash
docker logout