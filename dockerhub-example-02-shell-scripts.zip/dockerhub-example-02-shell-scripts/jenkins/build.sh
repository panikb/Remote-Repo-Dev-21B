#!/bin/bash
docker build -t darinpope/dp-alpine:latest .